<?php
// Text
$_['text_information']  = 'Информация';
$_['text_service']      = 'Поддержка';
$_['text_extra']        = 'Дополнительно';
$_['text_contact']      = 'Контакты';
$_['text_return']       = 'Возврат товара';
$_['text_sitemap']      = 'Карта сайта';
$_['text_manufacturer'] = 'Производители';
$_['text_voucher']      = 'Подарочные сертификаты';
$_['text_affiliate']    = 'Партнерская программа';
$_['text_special']      = 'Акции';
$_['text_account']      = 'Личный Кабинет';
$_['text_order']        = 'История заказов';
$_['text_wishlist']     = 'Заметки';
$_['text_newsletter']   = 'Подписка';
$_['text_powered'] 		= 'Разработка сайта <a href="http://colaweb.ru/internet-magazinyi">ColaWeb</a><br /> %s &copy; %s';
?>